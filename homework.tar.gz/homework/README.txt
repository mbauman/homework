------------------------------------------------------------------------
homework --- A class and style for the authoring of homework assignments
Author: Matt Bauman <mbauman@gmail.com>
Released under the LaTeX Project Public License v1.3c or later
See http://www.latex-project.org/lppl.txt
------------------------------------------------------------------------
This work contains a both a class and a package designed to simplify the
authoring of schoolwork, homework and assignments. The class and package
may be used independently of each other; the class provides some minor
modifications to the base `article` class, while the style adds commonly
needed packages and functionalities.

See homework.pdf for more information.
